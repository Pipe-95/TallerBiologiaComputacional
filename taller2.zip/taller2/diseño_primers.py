#!/usr/local/bin/

# Script por Felipe Arango Hernández
# Obtiene las secuencias de los primers para H. sapiens neanderthalensis con base en las posiciones encontradas que poseían SNP con H. sapiens. Guarda los primers en dos archivos FASTA

### Las posiciones que poseen sustituciones son: [20, 180, 297, 331, 402, 445, 480, 486, 549, 555, 580, 609, 697, 733, 883, 903, 921, 925, 1043, 1104]

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq

# Lee la secuencia de Cytb de H. sapiens neanderthalensis desde el archivo FASTA
sec_neanderthal = SeqIO.read("/home/farangoh/clase_biocomp/taller2/hsneanderthalensis_cytb_nt.fa", "fasta")

# Extraer secuencia primer forward
primer_f = sec_neanderthal.seq[473:497]
print(f"La longitud del primer forward es de {len(primer_f)} nucleotidos y su secuencia es: {primer_f}")

# Crear un objeto SeqRecord para el primer forward
primer_f_record = SeqRecord(primer_f, id="primer_forward", description="Primer forward de H. neanderthalensis")

# Escribir el primer forward en un archivo FASTA
SeqIO.write(primer_f_record, "/home/farangoh/clase_biocomp/taller2/primer_forward.fa", "fasta")

# Extraer secuencia primer reverse (complemento inverso)
primer_r = sec_neanderthal.seq[902:925].reverse_complement()
print(f"La longitud del primer reverse es de {len(primer_r)} nucleotidos y su secuencia es: {primer_r}")

# Crear un objeto SeqRecord para el primer reverse
primer_r_record = SeqRecord(primer_r, id="primer_reverse", description="Primer reverse de H. neanderthalensis")

# Escribir el primer reverse en un archivo FASTA
SeqIO.write(primer_r_record, "/home/farangoh/clase_biocomp/taller2/primer_reverse.fa", "fasta")


#!/bin/bash

#SBATCH --partition=learning                   # Partition (estudiantes)
#SBATCH --nodes=1
#SBATCH --ntasks=1                              # Number of tasks (processes)
#SBATCH --time=20:00                           # Walltime
#SBATCH --job-name=diseño_primers                 # Job name
#SBATCH --output=%x_%j.out                      # Stdout (%x-jobName, %j-jobId)
#SBATCH --error=%x_%j.err                       # Stderr (%x-jobName, %j-jobId)
#SBATCH --mail-type=ALL                         # Mail notification
#SBATCH --mail-user=farangoh@eafit.edu.co       # User Email


##### ENVIRONMENT CREATION #####
source activate biopython_py3.9

##### JOB COMMANDS ####
python /home/farangoh/clase_biocomp/taller2/diseño_primers.py

#!/usr/local/bin/

# Script por Felipe Arango Hernández
# Busca las secuencias del genoma mitocondrial completo de H. sapiens neanderthales & H. sapiens y extrae de ambas el CDS de Cytb

from Bio import Entrez, SeqIO

Entrez.email = "farangoh@eafit.edu.co"

try:
    # Buscar la secuencia mitocondrial completa de H. sapiens
    with Entrez.efetch(db="nucleotide", rettype="fasta", retmode="text", id="NC_012920.1") as handle1:
        seq_record1 = SeqIO.read(handle1, "fasta")

    # Extraer subsecuencia desde la posición 14747 a la 15887 (CDS de CytB)
    sub_seq1 = seq_record1.seq[14746:15887]  # Recordar que las posiciones en Python son 0-indexed

    # Crear un nuevo SeqRecord para guardar solo la CDS de CytB (H. sapiens)
    sub_seq_record1 = seq_record1[:0]  # Crear una copia vacía del SeqRecord original
    sub_seq_record1.seq = sub_seq1  # Asignar la subsecuencia
    sub_seq_record1.description = f"Subsecuencia de {seq_record1.id} desde 14747 a 15887 (CDS de CytB H. sapiens)"

    # Guardar la subsecuencia en un archivo FASTA
    SeqIO.write(sub_seq_record1, "/home/farangoh/clase_biocomp/taller2/hsapiens_cytb_nt.fa", "fasta")
    print("H. sapiens subsequence saved successfully.")

    # Buscar la secuencia mitocondrial completa de H. sapiens neanderthalensis
    with Entrez.efetch(db="nucleotide", rettype="fasta", retmode="text", id="NC_011137.1") as handle2:
        seq_record2 = SeqIO.read(handle2, "fasta")

    # Extraer subsecuencia desde la posición 14742 a la 15882 (CDS de CytB)
    sub_seq2 = seq_record2.seq[14741:15882]  # Posiciones ajustadas a 0-indexed

    # Crear un nuevo SeqRecord para guardar solo la CDS de H. sapiens neanderthalensis
    sub_seq_record2 = seq_record2[:0]  # Crear una copia vacía del SeqRecord original
    sub_seq_record2.seq = sub_seq2  # Asignar la subsecuencia
    sub_seq_record2.description = f"Subsecuencia de {seq_record2.id} desde 14742 a 15882 (CDS de CytB H. sapiens neanderthalensis)"

    # Guardar la subsecuencia en un archivo FASTA
    SeqIO.write(sub_seq_record2, "/home/farangoh/clase_biocomp/taller2/hsneanderthalensis_cytb_nt.fa", "fasta")
    print("Neanderthal subsequence saved successfully.")

except Exception as e:
    print(f"An error occurred: {e}")


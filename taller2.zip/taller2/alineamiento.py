#!/usr/local/bin/

# Script por Felipe Arango Hernández
# Alinea las secuencias de Cytb de H. sapiens y Neanderthal y arroja un vector con las posiciones que poseen SNPs
from Bio import Align, SeqIO

# Leer la primera secuencia desde el archivo FASTA (H. sapiens)
with open("/home/farangoh/clase_biocomp/taller2/hsapiens_cytb_nt.fa") as file1:
    sec_hsapiens = SeqIO.read(file1, "fasta").seq  # Extrae la secuencia de H. sapiens como objeto Seq
print(f"La longitud del CDS de Cytb de H. sapiens es de {len(sec_hsapiens)} nucleotidos")

# Leer la segunda secuencia desde el archivo FASTA (H. sapiens neanderthalensis)
with open("/home/farangoh/clase_biocomp/taller2/hsneanderthalensis_cytb_nt.fa") as file2:
    sec_hsneanderthalensis = SeqIO.read(file2, "fasta").seq # Extrae la secuencia de H. sapiens neanderthalensis como objeto Seq
print(f"La longitud del CDS de Cytb de Neanderthal es de {len(sec_hsneanderthalensis)} nucleotidos")
# Definir el tipo de alineamiento (pairwise)
aligner = Align.PairwiseAligner()

# Definir las penalidades
aligner.match_score = 1
aligner.mismatch_score = -1
aligner.open_gap_score = -1
aligner.extend_gap_score = -1

# Realizar el alineamiento con las dos secuencias
alignments = aligner.align(sec_hsapiens, sec_hsneanderthalensis)

# Encontrar el alineamiento con el mayor puntaje
best_alignment = max(alignments, key=lambda aln: aln.score)

# Imprimir el mejor alineamiento y su puntaje
print("El mejor alineamiento de las secuencias de Cytb de H. sapiens y Neanderthal es:")
print(best_alignment)
print(f"El puntaje del alineamiento es (Score): {best_alignment.score}")

#############################################
###OJO!!! Lo siguiente lo hice así porque después de observar el alineamiento me di cuenta que las secuencias poseen exactamente la misma longitud y que las diferencias entre ellas corresponden a SNPs y no hay INDELS. Por eso es fácil llenar un vector con las posiciones de los SNPs mediante el ciclo for que pongo a continuación, comparando base a base. Sin embargo, si se tuviesen INDELS y/o secuencias con una longitud diferente no tiene ningún sentido hacer esto!! OJO! 

# Lista para almacenar las posiciones con diferencias
differences = []

# Recorrer las secuencias alineadas y comparar base a base
for i, (base1, base2) in enumerate(zip(best_alignment.target, best_alignment.query)):
    if base1 != base2:  # Si hay alguna diferencia (sustituciones)
        # Ajustar las posiciones para que correspondan a la secuencia original
        differences.append(i+1)

# Imprimir las posiciones con diferencias
print(f"Las posiciones que poseen sustituciones son: {differences}")


